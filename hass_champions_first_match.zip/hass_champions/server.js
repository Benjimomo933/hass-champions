import express from "express";
import { createServer } from "node:http";
import { Server } from "socket.io";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer);
app.use(express.static(path.join(__dirname, "public")));

const questions = [
  { level:"EASY", type:"single", text:"What is democracy?", options:["Government run by the people","Government run only by judges","Government run by the army","Government run by one business"], answer:0, explain:"Democracy is government by the people, usually through elected representatives." },
  { level:"MEDIUM", type:"single", text:"Which level of government is mainly responsible for Australia's defence?", options:["Local","State","Federal","School"], answer:2, explain:"The federal government handles national responsibilities such as defence and foreign affairs." },
  { level:"MEDIUM", type:"single", text:"Which branch of government interprets laws and decides cases?", options:["Legislature","Executive","Judiciary","Cabinet"], answer:2, explain:"The judiciary is made up of courts that interpret and apply the law." },
  { level:"HARD", type:"single", text:"What does separation of powers aim to prevent?", options:["People voting in elections","One branch having all government power","Parliament debating Bills","Courts applying laws"], answer:1, explain:"Separating powers helps prevent any one branch from gaining complete control." },
  { level:"EASY", type:"truefalse", text:"Australia became a federation on 1 January 1901.", options:["True","False"], answer:0, explain:"The six colonies joined together as the Commonwealth of Australia on 1 January 1901." },
  { level:"MEDIUM", type:"multi", text:"Select BOTH houses of Australia's federal Parliament.", options:["House of Representatives","High Court","Senate","Cabinet"], answer:[0,2], explain:"The federal Parliament consists of the House of Representatives and the Senate." },
  { level:"HARD", type:"single", text:"A referendum to change the Australian Constitution needs a double majority. What does that mean?", options:["A majority nationally and a majority in at least four of the six states","A majority in every state and territory","Two votes from each eligible voter","Approval from both houses only"], answer:0, explain:"A referendum needs more than half the national vote and a majority in at least four of the six states." },
  { level:"MEDIUM", type:"truefalse", text:"Local councils are responsible for national immigration policy.", options:["True","False"], answer:1, explain:"Immigration is a federal responsibility. Councils focus on local services and facilities." },
  { level:"EASY", type:"single", text:"Which is a peaceful democratic way to make your voice heard?", options:["Threatening a representative","Damaging public property","Contacting your local MP","Stopping other people voting"], answer:2, explain:"Contacting your elected representative is a peaceful way to raise a concern." },
  { level:"HARD", type:"single", text:"Why is the Senate often called the house of review?", options:["It appoints all judges","It checks and reviews proposed laws passed through Parliament","It runs local councils","It chooses every state premier"], answer:1, explain:"The Senate examines Bills and can approve, amend or reject them." }
];

const rooms = new Map();
const makeCode = () => {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code;
  do { code = Array.from({length:5}, () => chars[Math.floor(Math.random()*chars.length)]).join(""); }
  while (rooms.has(code));
  return code;
};
function publicRoom(room) {
  return { code:room.code, players:[...room.players.values()].map(p=>({id:p.id,name:p.name,score:p.score,ready:p.ready})), status:room.status, questionIndex:room.questionIndex, total:questions.length };
}
function broadcast(room) { io.to(room.code).emit("room:update", publicRoom(room)); }
function sendQuestion(room) {
  const q = questions[room.questionIndex];
  room.answers.clear();
  room.deadline = Date.now() + 20000;
  io.to(room.code).emit("game:question", {index:room.questionIndex+1,total:questions.length,level:q.level,type:q.type,text:q.text,options:q.options,seconds:20,deadline:room.deadline});
  clearTimeout(room.timer);
  room.timer = setTimeout(() => finishQuestion(room), 20000);
}
function finishQuestion(room) {
  if (room.status !== "playing") return;
  clearTimeout(room.timer);
  const q = questions[room.questionIndex];
  const results = [];
  for (const p of room.players.values()) {
    const chosen = room.answers.get(p.id);
    const correct = q.type === "multi"
      ? Array.isArray(chosen) && chosen.length === q.answer.length && chosen.every(v=>q.answer.includes(v))
      : chosen === q.answer;
    if (correct) p.score += q.level === "HARD" ? 150 : q.level === "MEDIUM" ? 120 : 100;
    results.push({id:p.id,name:p.name,chosen:chosen??null,correct,score:p.score});
  }
  io.to(room.code).emit("game:reveal",{answer:q.answer,explanation:q.explain,results});
  room.status = "between"; broadcast(room);
  room.timer = setTimeout(() => {
    room.questionIndex++;
    if (room.questionIndex >= questions.length) {
      room.status = "finished";
      const leaderboard = [...room.players.values()].sort((a,b)=>b.score-a.score);
      io.to(room.code).emit("game:finished",{leaderboard}); broadcast(room);
    } else {
      room.status = "playing"; broadcast(room); sendQuestion(room);
    }
  },5000);
}
io.on("connection",socket=>{
  socket.on("room:create",({name},cb)=>{
    const code=makeCode(), player={id:socket.id,name:String(name||"Player").slice(0,18),score:0,ready:true};
    const room={code,host:socket.id,players:new Map([[socket.id,player]]),status:"lobby",questionIndex:0,answers:new Map(),timer:null,deadline:null};
    rooms.set(code,room); socket.join(code); cb?.({ok:true,code,playerId:socket.id}); broadcast(room);
  });
  socket.on("room:join",({code,name},cb)=>{
    const room=rooms.get(String(code||"").toUpperCase());
    if(!room||room.status!=="lobby") return cb?.({ok:false,error:"Room not found or the match has already started."});
    if(room.players.size>=8) return cb?.({ok:false,error:"This room is full (maximum 8 players)."});
    const player={id:socket.id,name:String(name||"Player").slice(0,18),score:0,ready:true};
    room.players.set(socket.id,player); socket.join(room.code); cb?.({ok:true,code:room.code,playerId:socket.id}); broadcast(room);
  });
  socket.on("game:start",({code},cb)=>{
    const room=rooms.get(code);
    if(!room||room.host!==socket.id) return cb?.({ok:false,error:"Only the host can start the match."});
    room.status="playing"; room.questionIndex=0;
    for(const p of room.players.values()) p.score=0;
    cb?.({ok:true}); broadcast(room); sendQuestion(room);
  });
  socket.on("game:answer",({code,answer},cb)=>{
    const room=rooms.get(code);
    if(!room||room.status!=="playing"||room.answers.has(socket.id)) return cb?.({ok:false});
    if(!room.players.has(socket.id)||Date.now()>room.deadline) return cb?.({ok:false});
    const q=questions[room.questionIndex];
    if(q.type==="multi"&&(!Array.isArray(answer)||answer.some(v=>!Number.isInteger(v)||v<0||v>=q.options.length))) return cb?.({ok:false});
    if(q.type!=="multi"&&(!Number.isInteger(answer)||answer<0||answer>=q.options.length)) return cb?.({ok:false});
    room.answers.set(socket.id,answer); cb?.({ok:true});
    io.to(room.code).emit("game:answered",{playerId:socket.id});
    if(room.answers.size===room.players.size) finishQuestion(room);
  });
  socket.on("disconnect",()=>{
    for(const [code,room] of rooms){
      if(room.players.has(socket.id)){
        room.players.delete(socket.id); room.answers.delete(socket.id);
        if(room.host===socket.id) room.host=room.players.keys().next().value;
        if(room.players.size===0){clearTimeout(room.timer);rooms.delete(code);}
        else {broadcast(room);if(room.status==="playing"&&room.answers.size===room.players.size)finishQuestion(room);}
      }
    }
  });
});
const port=process.env.PORT||3000;
httpServer.listen(port,()=>console.log(`HASS Champions running on port ${port}`));