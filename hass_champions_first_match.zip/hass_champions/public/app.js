const socket=io();
const $=id=>document.getElementById(id);
let roomCode=null,isHost=false,playerId=null,currentQuestion=null,selected=[],submitted=false,timerInterval=null,deadline=0;
function show(section){["home","lobby","game","results"].forEach(id=>$(id).classList.toggle("hidden",id!==section));}
function name(){return $("playerName").value.trim()||"Player";}
function showError(id,message){$(id).textContent=message||"";}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("createBtn").onclick=()=>{
  showError("homeError","");
  socket.emit("room:create",{name:name()},res=>{
    if(!res?.ok)return showError("homeError","Could not create a room. Try again.");
    roomCode=res.code;playerId=res.playerId;isHost=true;show("lobby");$("roomCodeDisplay").textContent=roomCode;
  });
};
$("joinBtn").onclick=()=>{
  showError("homeError","");
  socket.emit("room:join",{name:name(),code:$("roomCode").value.trim().toUpperCase()},res=>{
    if(!res?.ok)return showError("homeError",res?.error||"Could not join room.");
    roomCode=res.code;playerId=res.playerId;isHost=false;show("lobby");$("roomCodeDisplay").textContent=roomCode;
  });
};
$("startBtn").onclick=()=>socket.emit("game:start",{code:roomCode},res=>{if(!res?.ok)showError("lobbyError",res?.error||"Could not start match.");});
socket.on("room:update",room=>{
  if(room.code!==roomCode)return;
  $("players").innerHTML=room.players.map(p=>`<div class="player"><b>${escapeHtml(p.name)}</b><small>${p.score} XP · ${p.id===playerId?"YOU":"READY"}</small></div>`).join("");
  $("hostNote").textContent=isHost?"You're the host. Start when everyone has joined.":"Waiting for the host to start the match…";
  $("startBtn").classList.toggle("hidden",!isHost||room.status!=="lobby");
});
socket.on("game:question",q=>{
  currentQuestion=q;selected=[];submitted=false;show("game");
  $("qCounter").textContent=`QUESTION ${q.index} / ${q.total}`;$("level").textContent=q.level;
  $("level").style.color=q.level==="HARD"?"#ff9c8f":q.level==="MEDIUM"?"#ffd27a":"#8de5bd";
  $("questionText").textContent=q.text;$("questionType").textContent=q.type==="multi"?"SELECT ALL THAT APPLY":"CHOOSE ONE ANSWER";
  $("answerStatus").textContent="Choose carefully — your answer locks when submitted.";
  $("reveal").classList.add("hidden");$("submitBtn").disabled=false;$("submitBtn").textContent="LOCK IN ANSWER";
  $("options").innerHTML=q.options.map((o,i)=>`<button class="option" data-index="${i}"><span class="letter">${String.fromCharCode(65+i)}</span>${escapeHtml(o)}</button>`).join("");
  [...$("options").children].forEach(btn=>btn.onclick=()=>{
    if(submitted)return;const i=Number(btn.dataset.index);
    if(q.type==="multi")selected=selected.includes(i)?selected.filter(x=>x!==i):[...selected,i];else selected=[i];
    [...$("options").children].forEach((b,j)=>b.classList.toggle("selected",selected.includes(j)));
    $("submitBtn").disabled=selected.length===0;
  });
  deadline=q.deadline;clearInterval(timerInterval);
  timerInterval=setInterval(()=>{
    const left=Math.max(0,(deadline-Date.now())/1000);
    $("timer").textContent=Math.ceil(left);$("timer").classList.toggle("timer-low",left<=5);
    $("timerBar").style.width=`${left/20*100}%`;if(left<=0)clearInterval(timerInterval);
  },100);
});
$("submitBtn").onclick=()=>{
  if(submitted||!selected.length)return;submitted=true;$("submitBtn").disabled=true;
  socket.emit("game:answer",{code:roomCode,answer:currentQuestion.type==="multi"?selected:selected[0]},res=>{
    $("answerStatus").textContent=res?.ok?"Answer locked! Waiting for the other champions…":"Your answer could not be submitted.";
  });
  [...$("options").children].forEach(b=>b.disabled=true);
};
socket.on("game:reveal",data=>{
  clearInterval(timerInterval);$("submitBtn").disabled=true;
  const correctText=Array.isArray(data.answer)?data.answer.map(i=>currentQuestion.options[i]).join(" + "):currentQuestion.options[data.answer];
  const me=data.results.find(p=>p.id===playerId);$("reveal").classList.remove("hidden");
  $("reveal").innerHTML=`<b>${me?.correct?"✓ Correct answer!":"Round complete"}</b><p><b>Answer:</b> ${escapeHtml(correctText)}</p><p>${escapeHtml(data.explanation)}</p><p><b>Your score:</b> ${me?.score??0} XP</p><small>Next question in 5 seconds…</small>`;
  $("answerStatus").textContent="";
});
socket.on("game:finished",({leaderboard})=>{
  show("results");$("leaderboard").innerHTML=leaderboard.map((p,i)=>`<div class="player"><b>${i+1}. ${escapeHtml(p.name)} ${p.id===playerId?"(YOU)":""}</b><small>${p.score} XP</small></div>`).join("");
});
$("againBtn").onclick=()=>{roomCode=null;isHost=false;playerId=null;show("home");};
socket.on("connect_error",()=>showError("homeError","Can't connect to the game server. Check your connection or try again."));
