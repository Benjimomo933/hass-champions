# HASS Champions — first playable multiplayer build

## Included
- Live room creation and joining with a 5-character code
- Up to 8 players
- 10 Year 7 Australian HASS questions
- 20-second question timer
- Mixed easy, medium and hard questions
- Single-select, true/false and multi-select questions
- XP scoring and final leaderboard

## Run locally
1. Install Node.js (version 18 or newer).
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open http://localhost:3000

For friends on other devices, deploy this folder to a Node.js host that supports WebSockets (for example, Render or Railway). They then open the same public URL and enter the room code. A local-only address such as localhost will not work for friends elsewhere.

This is a starter build: rooms are held in server memory, so restarting the server ends active rooms. No accounts or personal information are required.
